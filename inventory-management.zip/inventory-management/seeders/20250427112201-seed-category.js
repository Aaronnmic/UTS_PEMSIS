'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('category', [
      {
        name: 'Elektronik',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Pakaian',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Peralatan Rumah Tangga',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ], {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('category', null, {});
  }
};
