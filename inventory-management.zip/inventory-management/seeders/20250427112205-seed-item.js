'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('item', [
      {
        name: 'Laptop ASUS',
        stock: 10,
        price: 10000000,
        category_id: 1,  // Ini harus ada di tabel category
        supplier_id: 1,  // Ini harus ada di tabel supplier
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Baju Kaos',
        stock: 50,
        price: 150000,
        category_id: 2,
        supplier_id: 2,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ], {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('item', null, {});
  }
};
