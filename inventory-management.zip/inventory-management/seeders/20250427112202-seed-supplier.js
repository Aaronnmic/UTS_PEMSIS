'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('supplier', [
      {
        name: 'Supplier 1',
        contact: '08123456789',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        name: 'Supplier 2',
        contact: '08234567890',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ], {});
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.bulkDelete('supplier', null, {});
  }
};
