const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Supplier = sequelize.define('Supplier', {
  name: DataTypes.STRING,
});

module.exports = Supplier;
