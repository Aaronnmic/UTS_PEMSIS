const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Item = sequelize.define('Item', {
  id: {  // Menambahkan kolom id
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stock: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  price: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
  },
  category_id: {  // Memastikan nama kolom sesuai dengan yang ada di database
    type: DataTypes.INTEGER,
    references: {
      model: 'category', // Nama tabel yang direferensikan
      key: 'id',
    },
    allowNull: true,
  },
  supplier_id: {  // Memastikan nama kolom sesuai dengan yang ada di database
    type: DataTypes.INTEGER,
    references: {
      model: 'supplier', // Nama tabel yang direferensikan
      key: 'id',
    },
    allowNull: true,
  },
  createdAt: { // Menambahkan kolom createdAt
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.NOW,
  },
  updatedAt: { // Menambahkan kolom updatedAt
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.NOW,
  }
}, {
  underscored: true, // Menggunakan snake_case untuk kolom
});

module.exports = Item;
