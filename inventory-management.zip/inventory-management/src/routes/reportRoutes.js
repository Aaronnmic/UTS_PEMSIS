const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');

router.get('/stock-summary', reportController.stockSummary);
router.get('/low-stock', reportController.lowStockItems);
router.get('/category/:categoryId', reportController.itemsByCategory);

module.exports = router;
