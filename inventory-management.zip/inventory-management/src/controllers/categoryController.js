const Category = require('../models/categoryModel');

exports.createCategory = async (req, res) => {
  const { name } = req.body;
  const category = await Category.create({ name });
  res.json(category);
};

exports.getCategories = async (req, res) => {
  const categories = await Category.findAll();
  res.json(categories);
};
