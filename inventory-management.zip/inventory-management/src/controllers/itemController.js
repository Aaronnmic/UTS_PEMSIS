exports.createItem = async (req, res) => {
    try {
      const { name, stock, price, category_id, supplier_id } = req.body; // Gunakan category_id dan supplier_id
      const item = await Item.create({ name, stock, price, category_id, supplier_id });
      res.status(201).json(item);
    } catch (error) {
      console.error(error);
      res.status(500).send({ message: 'Failed to create item' });
    }
  };
  
  exports.getItems = async (req, res) => {
    try {
      const items = await Item.findAll();
      res.json(items);
    } catch (error) {
      console.error('Error fetching items:', error);
      res.status(500).send({ message: 'Error fetching items', error: error.message });
    }
  };
  

  