const Item = require('../models/itemModel');
const Category = require('../models/categoryModel');
const Supplier = require('../models/supplierModel');
const { Op } = require('sequelize');

exports.stockSummary = async (req, res) => {
  const items = await Item.findAll();
  const totalStock = items.reduce((sum, item) => sum + item.stock, 0);
  const totalValue = items.reduce((sum, item) => sum + (item.stock * item.price), 0);
  const averagePrice = items.length ? totalValue / items.length : 0;
  
  res.json({ totalStock, totalValue, averagePrice });
};

exports.lowStockItems = async (req, res) => {
  const items = await Item.findAll({
    where: { stock: { [Op.lt]: 5 } }
  });
  res.json(items);
};

exports.itemsByCategory = async (req, res) => {
  const { categoryId } = req.params;
  const items = await Item.findAll({ where: { categoryId } });
  res.json(items);
};
