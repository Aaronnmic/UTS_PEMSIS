const Supplier = require('../models/supplierModel');

exports.createSupplier = async (req, res) => {
  const { name } = req.body;
  const supplier = await Supplier.create({ name });
  res.json(supplier);
};

exports.getSuppliers = async (req, res) => {
  const suppliers = await Supplier.findAll();
  res.json(suppliers);
};
